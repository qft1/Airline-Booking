<?php
session_start();
include('connection.php');

$message = "";
$error = "";


if (isset($_POST['delete_id'])) {
    $delete_id = mysqli_real_escape_string($con, $_POST['delete_id']);
    
    
    $checkQuery = "SELECT id FROM users WHERE id = '$delete_id'";
    $checkResult = mysqli_query($con, $checkQuery);
    
    if (mysqli_num_rows($checkResult) == 0) {
        $error = "User not found!";
    } else {
        $deleteQuery = "DELETE FROM users WHERE id = '$delete_id'";
        if (mysqli_query($con, $deleteQuery)) {
            $message = "User with ID $delete_id deleted successfully!";
        } else {
            $error = "Error deleting user: " . mysqli_error($con);
        }
    }
}


$query = "SELECT id, first_name, last_name, email, username FROM users ORDER BY id DESC";
$result = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #e0e0e0;
        }
        .back-btn {
            background: #667eea;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        .back-btn:hover {
            background: #764ba2;
        }
        .success-msg {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #2e7d32;
        }
        .error-msg {
            background: #ffebee;
            color: #c62828;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #c62828;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th {
            background: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        tr:hover {
            background: #f5f5f5;
        }
        .delete-btn {
            background: #dc3545;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }
        .delete-btn:hover {
            background: #c82333;
        }
        .no-users {
            text-align: center;
            padding: 40px;
            color: #666;
        }
    </style>
    <script>
        function confirmDelete(username) {
            return confirm('Are you sure you want to delete user "' + username + '"? This action cannot be undone.');
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>👥 User Management</h1>
                <p style="color: #666; margin-top: 5px;">Manage all registered users</p>
            </div>
            <a href="login.php" class="back-btn">← Back to Login</a>
        </div>

        <?php if(!empty($message)): ?>
            <div class="success-msg">✓ <?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if(!empty($error)): ?>
            <div class="error-msg">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if(mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td>
                <form method="POST" action="admin.php" style="display:inline;"
                    onsubmit="return confirmDelete('<?php echo htmlspecialchars($row['username']); ?>')">
                   <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                   <button type="submit" class="delete-btn">
                     🗑️ Delete
                   </button>
                </form>

                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-users">No users found in the database.</div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php mysqli_close($con); ?>