<?php

$host = "127.0.0.1";
$username = "root";
$password = "@Lulumag2"; 
$dbname = "db1";


$con = mysqli_connect($host, $username, $password, $dbname);


if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


mysqli_set_charset($con, "utf8");
?>