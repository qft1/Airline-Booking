<?php
session_start(); 
include('connection.php');

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

 
    if (empty($user) || empty($pass)) {
        $error = "Both username and password are required.";
    } else {

        $user = mysqli_real_escape_string($con, $user);

        $query = "SELECT * FROM users WHERE username = '$user'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            
            
            if ($pass === $row['password']) {
                
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['first_name'] = $row['first_name'];
                
           header("Location: http://localhost:53056/AirlineBooking/AirlineBooking/HomePage.html");
           exit();
           

            } else {
                $error = "Invalid username or password.";
            }
        } else {
            $error = "Invalid username or password.";
        }
    }
    
    
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — Airline Booking</title>
  <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: Arial, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
    }
    .login-container {
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        max-width: 450px;
        width: 100%;
        padding: 40px;
    }
    .login-header {
        text-align: center;
        margin-bottom: 30px;
    }
    .login-header h1 {
        color: #333;
        font-size: 28px;
        margin-bottom: 10px;
    }
    .login-header p {
        color: #666;
        font-size: 14px;
    }
    .error-msg {
        background: #ffebee;
        color: #c62828;
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 20px;
        border-left: 4px solid #c62828;
        font-size: 14px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #333;
        font-size: 14px;
    }
    .form-group input {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 6px;
        font-size: 14px;
        transition: border-color 0.3s;
    }
    .form-group input:focus {
        outline: none;
        border-color: #667eea;
    }
    .required {
        color: #c62828;
    }
    .submit-btn {
        width: 100%;
        padding: 14px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 16px;
        font-weight: 600;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    .submit-btn:active {
        transform: translateY(0);
    }
    .note {
        text-align: center;
        margin-top: 20px;
        font-size: 13px;
        color: #666;
        padding: 15px;
        background: #f5f5f5;
        border-radius: 6px;
    }
    .guest-link {
        display: block;
        text-align: center;
        margin-top: 20px;
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
        font-size: 15px;
        transition: color 0.3s;
    }
    .guest-link:hover {
        color: #764ba2;
        text-decoration: underline;
    }
    .signup-link {
        text-align: center;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
        font-size: 14px;
        color: #666;
    }
    .signup-link a {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
    }
    .signup-link a:hover {
        text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="login-container">
  <div class="login-header">
    <h1>✈️ Welcome Back!</h1>
    <p>Login to access your travel bookings</p>
  </div>
  
  <?php if(!empty($error)): ?>
    <div class="error-msg">⚠️ <?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>
  
  <form method="POST" action="login.php">
    <div class="form-group">
      <label for="username">Username <span class="required">*</span></label>
      <input type="text" id="username" name="username" placeholder="Enter your username" required autofocus>
    </div>

    <div class="form-group">
      <label for="password">Password <span class="required">*</span></label>
      <input type="password" id="password" name="password" placeholder="Enter your password" required>
    </div>
    
    <button type="submit" class="submit-btn">Login</button>
    
    <div class="note">
      <strong>📝 Note:</strong> If you continue as a guest, personal information will be required to confirm the reservation.
    </div>

    <a href="http://localhost:53056/AirlineBooking/AirlineBooking/HomePage.html" class="guest-link">
      👤 Continue as a guest →
    </a>
  </form>
  
  <div class="signup-link">
    Don't have an account? <a href="signup.php">Sign up here</a>
  </div>
    <div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #e0e0e0;">
    <a href="admin.php" style="color: #dc3545; text-decoration: none; font-size: 13px; font-weight: 600;">
        🔧 Admin: Manage Users
    </a>
</div>
</div>

</body>
</html>