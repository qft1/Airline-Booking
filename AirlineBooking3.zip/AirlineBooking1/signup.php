<?php
session_start();
include('connection.php');

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  
    $fname = trim($_POST['first_name']);
    $lname = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $user  = trim($_POST['username']);
    $pass  = trim($_POST['password']);


    if (empty($fname) || empty($lname) || empty($email) || empty($user) || empty($pass)) {
        $error = "All fields are required.";
    }
  
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    }

    elseif (strlen($pass) < 6) {
        $error = "Password must be at least 6 characters long.";
    }
    else {

        $fname = mysqli_real_escape_string($con, $fname);
        $lname = mysqli_real_escape_string($con, $lname);
        $email = mysqli_real_escape_string($con, $email);
        $user  = mysqli_real_escape_string($con, $user);


        $checkQuery = "SELECT * FROM users WHERE username = '$user'";
        $checkResult = mysqli_query($con, $checkQuery);

        if (mysqli_num_rows($checkResult) > 0) {
            $error = "Username already exists. Please choose another one.";
        } 

        else {
            $checkEmail = "SELECT * FROM users WHERE email = '$email'";
            $emailResult = mysqli_query($con, $checkEmail);
            
            if (mysqli_num_rows($emailResult) > 0) {
                $error = "Email already registered. Please use another email.";
            }
            else {

                $insertQuery = "INSERT INTO users 
                (first_name, last_name, email, username, password)
                VALUES 
                ('$fname', '$lname', '$email', '$user', '$pass')";

                if (mysqli_query($con, $insertQuery)) {
                    $success = "Account created successfully! Redirecting to login...";
                    header("refresh:2;url=login.php");
                } else {
                    $error = "Error: " . mysqli_error($con);
                }
            }
        }
    }
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Travel Booking</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .signup-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
            padding: 40px;
        }
        .signup-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .signup-header h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        .signup-header p {
            color: #666;
            font-size: 14px;
        }
        .error-msg {
            background: #ffebee;
            color: #c62828;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #c62828;
            font-size: 14px;
        }
        .success-msg {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #2e7d32;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        .required {
            color: #c62828;
        }
        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 10px;
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .submit-btn:active {
            transform: translateY(0);
        }
        .login-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
        }
        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="signup-container">
    <div class="signup-header">
        <h1>🌍 Join Travel Booking</h1>
        <p>Create your account to start exploring</p>
    </div>

    <?php if(!empty($error)): ?>
        <div class="error-msg">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if(!empty($success)): ?>
        <div class="success-msg">✓ <?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="POST" action="signup.php">
        <div class="form-group">
            <label for="first_name">First Name <span class="required">*</span></label>
            <input type="text" id="first_name" name="first_name" placeholder="Enter first name" required 
                   value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>">
        </div>

        <div class="form-group">
            <label for="last_name">Last Name <span class="required">*</span></label>
            <input type="text" id="last_name" name="last_name" placeholder="Enter last name" required
                   value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>">
        </div>

        <div class="form-group">
            <label for="email">Email <span class="required">*</span></label>
            <input type="email" id="email" name="email" placeholder="your.email@example.com" required
                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        </div>

        <div class="form-group">
            <label for="username">Username <span class="required">*</span></label>
            <input type="text" id="username" name="username" placeholder="Choose a username" required
                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
        </div>

        <div class="form-group">
            <label for="password">Password (min 6 characters) <span class="required">*</span></label>
            <input type="password" id="password" name="password" placeholder="Create a strong password" required minlength="6">
        </div>

        <button type="submit" class="submit-btn">Create Account</button>
    </form>

    <div class="login-link">
        Already have an account? <a href="login.php">Login here</a>
    </div>
</div>

</body>
</html>